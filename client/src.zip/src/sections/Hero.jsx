import { ArrowDown, ArrowUpRight } from "lucide-react";

export default function Hero() {
  return (
    <section
      id="home"
      className="flex justify-center place-items-center top-10"
      aria-labelledby="hero-title"
    >
      <div
        className="hero-content  flex-col justify-center place-items-center"
        data-reveal
      >
        <div className="hero-eyebrow">
          <span className="eyebrow-dot" /> PORTFOLIO / 2026
        </div>
        <h1
          id="hero-title" 
          className="max-w-5xl text-[clamp(3.25rem,9vw,8rem)] font-black uppercase leading-[0.88] tracking-[-0.065em] text-white"
        >
          Software
          <br />
          <span className="text-neutral-800">Engineer</span>
        </h1>
        <p className="hero-description w-full max-w-2xl text-left self-right">
          Computer engineering graduate who enjoys building for the web,
          learning how systems work, and turning messy ideas into simple
          products.
        </p>{" "}
        <div className="hero-actions">
          <a className="button-primary" href="#projects">
            Explore my work <ArrowUpRight size={18} />
          </a>
          <a className="button-quiet" href="#contact">
            Let's connect <ArrowUpRight size={17} />
          </a>
        </div>
        <div className="hero-stats">
          <div>
            <strong>03+</strong>
            <span>PROJECTS BUILT</span>
          </div>
          <div>
            <strong>06+</strong>
            <span>CORE TECHNOLOGIES</span>
          </div>
          <div>
            <strong>2026</strong>
            <span>GRADUATE</span>
          </div>
        </div>
        <a className="scroll-cue" href="#projects">
          SCROLL TO EXPLORE <ArrowDown size={14} />
        </a>
      </div>
    </section>
  );
}
